//<Variables>
var rabbit,rabbitImg,rabbitAnim,backGround,backGroundImg,jump,foodStock;
var ball,ballImg,mouseSprite,mouseSpriteImg;
var button;



//</Variables>

function preload()
{
rabbitImg = loadImage("images/Hare-a.png");
backGroundImg = loadImage("images/dood.jpg");
ballImg = loadImage("images/ball.png");
jump = loadImage("images/hare-b.png");
rabbitAnim = loadAnimation("hare-b.png","hare-c.png")
}

function setup() {
	createCanvas(600, 400);
	foodStock = Database.ref('Food Stock');
	foodStock.on("value",readStock);
}


function draw() {  
background("lightBlue");

//<background>
backGround = createSprite(300,200,1000,800);
backGround.addImage(backGroundImg);
//</background>

//<mouseSprite>
mouseSprite = createSprite(0,0,10,10);
mouseSprite.x = mouseX;
mouseSprite.y = mouseY;
//</mouseSprite>

//<rabbit>
rabbit = createSprite(270,300);
rabbit.addImage(rabbitImg);
rabbit.scale = 0.6;
//</rabbit>

//<ball>
ball = createSprite(150,340)
ball.addImage(ballImg)
ball.scale = 0.5;
//</ball>

if(mouseSprite.isTouching(ball)){
ball.scale = 0.8;
}

//ball
if(keyDown("b")){
ball.x = mouseX;
ball.y = mouseY;
rabbit.x = ball.x;
}
if(rabbit.velocityX>1){
rabbit.setAnimation(rabbitAnim);
}
drawSprites();	
}

